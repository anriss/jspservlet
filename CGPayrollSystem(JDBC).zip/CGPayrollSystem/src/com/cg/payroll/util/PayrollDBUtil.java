package com.cg.payroll.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class PayrollDBUtil {
	private static Connection con = null;
	
	public static Connection getDBConnection () {
		if (con == null) {
			Properties payrollProperties = new Properties();
			
			try {
				payrollProperties.load(new FileInputStream(new File(".//resources//payroll.properties")));
				String driver = payrollProperties.getProperty("driver");
				String url = payrollProperties.getProperty("url");
				String user = payrollProperties.getProperty("user");
				String password = payrollProperties.getProperty("password");
				
				Class.forName(driver);
				
				con = DriverManager.getConnection(url, user, password);
				
			} catch (IOException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return con;
	}
}

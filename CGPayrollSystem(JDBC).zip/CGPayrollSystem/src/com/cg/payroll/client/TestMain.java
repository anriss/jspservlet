package com.cg.payroll.client;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDAOImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotfoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.util.PayrollDBUtil;

public class TestMain {

	public static void main(String[] args) {
		PayrollServices services = new PayrollServicesImpl();

		int associateId = services.acceptAssociateDetails("Akshay", "Kataria", "akshaykataria03@gmail.com", "fsbu", "Intern", "7985vsgg0", 67800, 700000, 75208, 28000, 769456957, "CITI", "citi001");
		System.out.println("Associate Id:-" + associateId);
		
		try {
			System.out.println(services.calculateNetSalary(associateId));
		} catch (AssociateDetailsNotfoundException e) {
			e.printStackTrace();
		}
	}

}
